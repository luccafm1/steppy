
Logos by [Kerbalized Flags](https://forum.kerbalspaceprogram.com/index.php?/topic/102185-112x-kerbalized-flags-agencies-and-decal-textures-03aug21-and-suits-v10-15sep21-more-slim-suits/) author
